from setuptools import setup

setup(
    version='1.0',
    scripts=['bin/jupyckage'],
)
